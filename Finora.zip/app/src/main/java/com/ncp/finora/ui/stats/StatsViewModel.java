package com.ncp.finora.ui.stats;

import androidx.core.util.Pair;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.ncp.finora.data.local.model.CategoryTotal;
import com.ncp.finora.data.repository.TransactionRepository;
import com.ncp.finora.util.Constants;
import com.ncp.finora.util.Formatters;

import java.time.YearMonth;
import java.util.List;

public class StatsViewModel extends ViewModel {
    private final int userId;
    private final TransactionRepository repo;

    private final MutableLiveData<YearMonth> month = new MutableLiveData<>(YearMonth.now());
    private final MutableLiveData<String> type = new MutableLiveData<>(Constants.EXPENSE);

    private final LiveData<Double> income;
    private final LiveData<Double> expense;
    private final LiveData<List<CategoryTotal>> breakdown;
    private final LiveData<String> monthLabel;

    public StatsViewModel(int userId, TransactionRepository repo) {
        this.userId = userId;
        this.repo = repo;

        monthLabel = Transformations.map(month, Formatters::monthLabel);
        income = Transformations.switchMap(month, m ->
                repo.total(userId, Constants.INCOME, Formatters.monthStart(m), Formatters.nextMonthStart(m)));
        expense = Transformations.switchMap(month, m ->
                repo.total(userId, Constants.EXPENSE, Formatters.monthStart(m), Formatters.nextMonthStart(m)));

        MediatorLiveData<Pair<YearMonth, String>> query = new MediatorLiveData<>();
        Runnable emit = () -> {
            YearMonth m = month.getValue();
            String t = type.getValue();
            if (m != null && t != null) query.setValue(new Pair<>(m, t));
        };
        query.addSource(month, v -> emit.run());
        query.addSource(type, v -> emit.run());
        breakdown = Transformations.switchMap(query, q ->
                repo.categoryTotals(userId, q.second, Formatters.monthStart(q.first),
                        Formatters.nextMonthStart(q.first)));
    }

    public LiveData<String> getMonthLabel() { return monthLabel; }
    public LiveData<String> getType() { return type; }
    public LiveData<Double> getIncome() { return income; }
    public LiveData<Double> getExpense() { return expense; }
    public LiveData<List<CategoryTotal>> getBreakdown() { return breakdown; }

    public void previousMonth() {
        YearMonth m = month.getValue();
        if (m != null) month.setValue(m.minusMonths(1));
    }

    public void nextMonth() {
        YearMonth m = month.getValue();
        if (m != null && m.isBefore(YearMonth.now())) month.setValue(m.plusMonths(1));
    }

    public void setType(String newType) {
        if (!newType.equals(type.getValue())) type.setValue(newType);
    }
}
