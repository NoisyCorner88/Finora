package com.ncp.finora.ui.activity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.ncp.finora.FinoraApp;
import com.ncp.finora.R;
import com.ncp.finora.ui.home.TransactionAdapter;
import com.ncp.finora.util.Constants;
import com.ncp.finora.util.UiUtils;

public class ActivityFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_activity, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ActivityViewModel viewModel = new ViewModelProvider(this, FinoraApp.factory(requireContext()))
                .get(ActivityViewModel.class);

        TextView chipAll = view.findViewById(R.id.chipAll);
        TextView chipIncome = view.findViewById(R.id.chipIncome);
        TextView chipExpense = view.findViewById(R.id.chipExpense);
        TextView tvIncome = view.findViewById(R.id.tvActivityIncome);
        TextView tvExpense = view.findViewById(R.id.tvActivityExpense);
        TextView tvAvatar = view.findViewById(R.id.tvAvatarActivity);
        TextView tvMonth = view.findViewById(R.id.tvActivityMonth);

        String userName = FinoraApp.container(requireContext()).session.getName();
        if (tvAvatar != null) tvAvatar.setText(UiUtils.initial(userName));
        if (tvMonth != null) {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MMMM yyyy", new java.util.Locale("id", "ID"));
            tvMonth.setText(sdf.format(new java.util.Date()) + " ∨");
        }

        RecyclerView rv = view.findViewById(R.id.rvActivity);
        View empty = view.findViewById(R.id.tvEmptyActivity);
        TransactionAdapter adapter = new TransactionAdapter();
        rv.setAdapter(adapter);

        chipAll.setOnClickListener(v -> viewModel.setFilter(Constants.ALL));
        chipIncome.setOnClickListener(v -> viewModel.setFilter(Constants.INCOME));
        chipExpense.setOnClickListener(v -> viewModel.setFilter(Constants.EXPENSE));

        viewModel.getFilter().observe(getViewLifecycleOwner(), f -> {
            UiUtils.setChipSelected(chipAll, Constants.ALL.equals(f));
            UiUtils.setChipSelected(chipIncome, Constants.INCOME.equals(f));
            UiUtils.setChipSelected(chipExpense, Constants.EXPENSE.equals(f));
        });
        viewModel.getTransactions().observe(getViewLifecycleOwner(), list -> {
            adapter.submitList(list);
            double inc = 0;
            double exp = 0;
            if (list != null) {
                for (com.ncp.finora.ui.model.TransactionUi t : list) {
                    if (t.income) inc += t.rawAmount;
                    else exp += t.rawAmount;
                }
            }
            if (tvIncome != null) tvIncome.setText(com.ncp.finora.util.Formatters.currency(inc));
            if (tvExpense != null) tvExpense.setText(com.ncp.finora.util.Formatters.currency(exp));

            boolean isEmpty = list == null || list.isEmpty();
            empty.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
            rv.setVisibility(isEmpty ? View.GONE : View.VISIBLE);
        });
    }
}
