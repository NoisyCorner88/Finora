package com.ncp.finora.ui.scan;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ExperimentalGetImage;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.ncp.finora.FinoraApp;
import com.ncp.finora.R;
import com.ncp.finora.data.local.model.ParsedReceipt;
import com.ncp.finora.util.Formatters;
import com.ncp.finora.util.ReceiptOcrParser;
import com.ncp.finora.util.UiUtils;

import java.io.File;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ScanReceiptActivity extends AppCompatActivity {

    private PreviewView viewFinder;
    private ImageView btnFlash;
    private ProgressBar progressScan;
    private LinearLayout layoutLiveDetection;
    private TextView tvLiveMerchant, tvLiveTotal;

    private ProcessCameraProvider cameraProvider;
    private Camera camera;
    private ImageCapture imageCapture;
    private ExecutorService cameraExecutor;
    private TextRecognizer textRecognizer;

    private int lensFacing = CameraSelector.LENS_FACING_BACK;
    private boolean isFlashOn = false;
    private boolean isProcessing = false;
    private long lastAnalysisTime = 0;

    private final ActivityResultLauncher<String> cameraPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    startCamera();
                } else {
                    Toast.makeText(this, "Izin kamera diperlukan untuk memindai struk", Toast.LENGTH_SHORT).show();
                }
            });

    private final ActivityResultLauncher<String> galleryLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) {
                    processImageUri(uri);
                }
            });

    private final ActivityResultLauncher<Intent> detailLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK) {
                    finish();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_receipt);

        initViews();
        textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        cameraExecutor = Executors.newSingleThreadExecutor();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA);
        }
    }

    private void initViews() {
        viewFinder = findViewById(R.id.viewFinder);
        btnFlash = findViewById(R.id.btnFlash);
        progressScan = findViewById(R.id.progressScan);
        layoutLiveDetection = findViewById(R.id.layoutLiveDetection);
        tvLiveMerchant = findViewById(R.id.tvLiveMerchant);
        tvLiveTotal = findViewById(R.id.tvLiveTotal);

        TextView tvAvatar = findViewById(R.id.tvAvatar);
        String name = FinoraApp.container(this).session.getName();
        tvAvatar.setText(UiUtils.initial(name));

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        btnFlash.setOnClickListener(v -> toggleFlash());

        findViewById(R.id.btnGallery).setOnClickListener(v -> openGallery());

        findViewById(R.id.btnCapture).setOnClickListener(v -> captureAndProcess());

        findViewById(R.id.btnAutoScan).setOnClickListener(v -> captureAndProcess());

        findViewById(R.id.btnSwitchCamera).setOnClickListener(v -> switchCamera());
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture =
                ProcessCameraProvider.getInstance(this);

        cameraProviderFuture.addListener(() -> {
            try {
                cameraProvider = cameraProviderFuture.get();
                bindCameraUseCases();
            } catch (ExecutionException | InterruptedException e) {
                Toast.makeText(this, "Gagal menginisialisasi kamera", Toast.LENGTH_SHORT).show();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void bindCameraUseCases() {
        if (cameraProvider == null) return;
        cameraProvider.unbindAll();

        CameraSelector cameraSelector = new CameraSelector.Builder()
                .requireLensFacing(lensFacing)
                .build();

        Preview preview = new Preview.Builder().build();
        preview.setSurfaceProvider(viewFinder.getSurfaceProvider());

        imageCapture = new ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build();

        ImageAnalysis imageAnalysis = new ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build();

        imageAnalysis.setAnalyzer(cameraExecutor, this::analyzeLiveFrame);

        try {
            camera = cameraProvider.bindToLifecycle(
                    this, cameraSelector, preview, imageCapture, imageAnalysis);
        } catch (Exception e) {
            Toast.makeText(this, "Gagal menghubungkan kamera: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @OptIn(markerClass = ExperimentalGetImage.class)
    private void analyzeLiveFrame(@NonNull ImageProxy imageProxy) {
        long current = System.currentTimeMillis();
        // Analyze once every 1200ms to conserve CPU and smooth UI
        if (isProcessing || current - lastAnalysisTime < 1200) {
            imageProxy.close();
            return;
        }
        lastAnalysisTime = current;

        if (imageProxy.getImage() != null) {
            InputImage inputImage = InputImage.fromMediaImage(
                    imageProxy.getImage(), imageProxy.getImageInfo().getRotationDegrees());

            textRecognizer.process(inputImage)
                    .addOnSuccessListener(visionText -> {
                        updateLiveDetection(visionText);
                        imageProxy.close();
                    })
                    .addOnFailureListener(e -> imageProxy.close());
        } else {
            imageProxy.close();
        }
    }

    private void updateLiveDetection(Text text) {
        if (isFinishing() || isDestroyed()) return;
        String raw = text.getText().trim();
        if (raw.length() < 5) {
            runOnUiThread(() -> layoutLiveDetection.setVisibility(View.GONE));
            return;
        }

        ParsedReceipt parsed = ReceiptOcrParser.parse(text, null);
        runOnUiThread(() -> {
            if (parsed.merchantName != null && !parsed.merchantName.equals("Toko / Merchant")) {
                layoutLiveDetection.setVisibility(View.VISIBLE);
                tvLiveMerchant.setText(parsed.merchantName);
                if (parsed.total > 0) {
                    tvLiveTotal.setText(Formatters.currency(parsed.total) + " ✔");
                } else {
                    tvLiveTotal.setText("Estimasi Total...");
                }
            } else {
                layoutLiveDetection.setVisibility(View.GONE);
            }
        });
    }

    private void toggleFlash() {
        if (camera != null && camera.getCameraInfo().hasFlashUnit()) {
            isFlashOn = !isFlashOn;
            camera.getCameraControl().enableTorch(isFlashOn);
            btnFlash.setImageResource(R.drawable.ic_flash);
            btnFlash.setAlpha(isFlashOn ? 1.0f : 0.5f);
        } else {
            Toast.makeText(this, "Lampu kilat tidak tersedia", Toast.LENGTH_SHORT).show();
        }
    }

    private void switchCamera() {
        lensFacing = (lensFacing == CameraSelector.LENS_FACING_BACK)
                ? CameraSelector.LENS_FACING_FRONT
                : CameraSelector.LENS_FACING_BACK;
        bindCameraUseCases();
    }

    private void openGallery() {
        galleryLauncher.launch("image/*");
    }

    private void captureAndProcess() {
        if (imageCapture == null || isProcessing) return;

        isProcessing = true;
        progressScan.setVisibility(View.VISIBLE);

        File photoFile = new File(getCacheDir(), "scan_receipt_" + System.currentTimeMillis() + ".jpg");
        ImageCapture.OutputFileOptions options =
                new ImageCapture.OutputFileOptions.Builder(photoFile).build();

        imageCapture.takePicture(options, ContextCompat.getMainExecutor(this),
                new ImageCapture.OnImageSavedCallback() {
                    @Override
                    public void onImageSaved(@NonNull ImageCapture.OutputFileResults outputFileResults) {
                        processCapturedFile(photoFile);
                    }

                    @Override
                    public void onError(@NonNull ImageCaptureException exception) {
                        isProcessing = false;
                        progressScan.setVisibility(View.GONE);
                        Toast.makeText(ScanReceiptActivity.this, "Gagal mengambil foto: " + exception.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void processCapturedFile(File photoFile) {
        try {
            InputImage inputImage = InputImage.fromFilePath(this, Uri.fromFile(photoFile));
            textRecognizer.process(inputImage)
                    .addOnSuccessListener(visionText -> {
                        isProcessing = false;
                        progressScan.setVisibility(View.GONE);
                        ParsedReceipt parsed = ReceiptOcrParser.parse(visionText, photoFile.getAbsolutePath());
                        openDetailScreen(parsed);
                    })
                    .addOnFailureListener(e -> {
                        isProcessing = false;
                        progressScan.setVisibility(View.GONE);
                        Toast.makeText(this, "Gagal mengenali teks: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        } catch (Exception e) {
            isProcessing = false;
            progressScan.setVisibility(View.GONE);
            Toast.makeText(this, "Gagal memproses gambar: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void processImageUri(Uri uri) {
        isProcessing = true;
        progressScan.setVisibility(View.VISIBLE);

        try {
            InputImage inputImage = InputImage.fromFilePath(this, uri);
            textRecognizer.process(inputImage)
                    .addOnSuccessListener(visionText -> {
                        isProcessing = false;
                        progressScan.setVisibility(View.GONE);
                        ParsedReceipt parsed = ReceiptOcrParser.parse(visionText, uri.toString());
                        openDetailScreen(parsed);
                    })
                    .addOnFailureListener(e -> {
                        isProcessing = false;
                        progressScan.setVisibility(View.GONE);
                        Toast.makeText(this, "Gagal membaca teks struk: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        } catch (Exception e) {
            isProcessing = false;
            progressScan.setVisibility(View.GONE);
            Toast.makeText(this, "Gagal membuka gambar: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void openDetailScreen(ParsedReceipt receipt) {
        Intent intent = new Intent(this, ReceiptDetailActivity.class);
        intent.putExtra(ReceiptDetailActivity.EXTRA_PARSED_RECEIPT, receipt);
        detailLauncher.launch(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (cameraExecutor != null) {
            cameraExecutor.shutdown();
        }
        if (textRecognizer != null) {
            textRecognizer.close();
        }
    }
}
