package com.ncp.finora.ui.stats;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.ncp.finora.FinoraApp;
import com.ncp.finora.R;
import com.ncp.finora.data.local.model.CategoryTotal;
import com.ncp.finora.util.Formatters;
import com.ncp.finora.util.UiUtils;

public class StatsFragment extends Fragment {

    private double currentIncome = 0;
    private double currentExpense = 0;
    private static final double BUDGET_LIMIT = 8000000;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_stats, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        StatsViewModel viewModel = new ViewModelProvider(this, FinoraApp.factory(requireContext()))
                .get(StatsViewModel.class);

        TextView tvMonth = view.findViewById(R.id.tvMonth);
        TextView tvIncome = view.findViewById(R.id.tvIncome);
        TextView tvExpense = view.findViewById(R.id.tvExpense);
        TextView tvNetSurplus = view.findViewById(R.id.tvNetSurplus);
        TextView tvBudgetLimit = view.findViewById(R.id.tvBudgetLimit);
        TextView tvBudgetRemaining = view.findViewById(R.id.tvBudgetRemaining);
        TextView tvBudgetPercent = view.findViewById(R.id.tvBudgetPercent);
        ProgressBar progressBudget = view.findViewById(R.id.progressBudget);

        TextView pillThisMonth = view.findViewById(R.id.pillThisMonth);
        TextView pillLastMonth = view.findViewById(R.id.pillLastMonth);
        TextView pillAllTime = view.findViewById(R.id.pillAllTime);

        TextView tvAvatar = view.findViewById(R.id.tvAvatarStats);
        String name = FinoraApp.container(requireContext()).session.getName();
        tvAvatar.setText(UiUtils.initial(name));

        View empty = view.findViewById(R.id.tvEmptyStats);
        RecyclerView rv = view.findViewById(R.id.rvCategories);
        CategoryStatAdapter adapter = new CategoryStatAdapter();
        rv.setAdapter(adapter);

        pillThisMonth.setOnClickListener(v -> {
            pillThisMonth.setBackgroundResource(R.drawable.bg_chip_selected);
            pillThisMonth.setTextColor(0xFFFFFFFF);
            pillLastMonth.setBackgroundResource(android.R.color.transparent);
            pillLastMonth.setTextColor(0xFF667085);
            pillAllTime.setBackgroundResource(android.R.color.transparent);
            pillAllTime.setTextColor(0xFF667085);
        });

        pillLastMonth.setOnClickListener(v -> {
            viewModel.previousMonth();
            pillLastMonth.setBackgroundResource(R.drawable.bg_chip_selected);
            pillLastMonth.setTextColor(0xFFFFFFFF);
            pillThisMonth.setBackgroundResource(android.R.color.transparent);
            pillThisMonth.setTextColor(0xFF667085);
            pillAllTime.setBackgroundResource(android.R.color.transparent);
            pillAllTime.setTextColor(0xFF667085);
        });

        pillAllTime.setOnClickListener(v -> {
            pillAllTime.setBackgroundResource(R.drawable.bg_chip_selected);
            pillAllTime.setTextColor(0xFFFFFFFF);
            pillThisMonth.setBackgroundResource(android.R.color.transparent);
            pillThisMonth.setTextColor(0xFF667085);
            pillLastMonth.setBackgroundResource(android.R.color.transparent);
            pillLastMonth.setTextColor(0xFF667085);
        });

        viewModel.getMonthLabel().observe(getViewLifecycleOwner(), tvMonth::setText);

        viewModel.getIncome().observe(getViewLifecycleOwner(), v -> {
            currentIncome = v == null ? 0 : v;
            tvIncome.setText(Formatters.currency(currentIncome));
            updateSurplusAndBudget(tvNetSurplus, tvBudgetLimit, tvBudgetRemaining, tvBudgetPercent, progressBudget);
        });

        viewModel.getExpense().observe(getViewLifecycleOwner(), v -> {
            currentExpense = v == null ? 0 : v;
            tvExpense.setText(Formatters.currency(currentExpense));
            updateSurplusAndBudget(tvNetSurplus, tvBudgetLimit, tvBudgetRemaining, tvBudgetPercent, progressBudget);
        });

        viewModel.getBreakdown().observe(getViewLifecycleOwner(), list -> {
            adapter.submit(list);
            boolean isEmpty = list == null || list.isEmpty();
            empty.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
            rv.setVisibility(isEmpty ? View.GONE : View.VISIBLE);
        });
    }

    private void updateSurplusAndBudget(TextView tvNetSurplus, TextView tvBudgetLimit,
                                        TextView tvBudgetRemaining, TextView tvBudgetPercent,
                                        ProgressBar progressBudget) {
        double surplus = currentIncome - currentExpense;
        boolean pos = surplus >= 0;
        tvNetSurplus.setText((pos ? "+" : "") + Formatters.currency(surplus));
        tvNetSurplus.setTextColor(pos ? 0xFF00A879 : 0xFFFF253B);

        tvBudgetLimit.setText("Batas Anggaran: " + Formatters.currency(BUDGET_LIMIT));
        double remaining = Math.max(0, BUDGET_LIMIT - currentExpense);
        tvBudgetRemaining.setText("Tersisa " + Formatters.currency(remaining));

        int percent = (int) Math.min(100, Math.round((currentExpense / BUDGET_LIMIT) * 100));
        progressBudget.setProgress(percent);
        tvBudgetPercent.setText(percent + "% terpakai");
    }
}
