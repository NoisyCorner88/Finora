package com.ncp.finora.ui.card;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.ncp.finora.FinoraApp;
import com.ncp.finora.R;
import com.ncp.finora.data.local.entity.PaymentMethodEntity;
import com.ncp.finora.data.local.model.PaymentMethodBalance;
import com.ncp.finora.util.Constants;
import com.ncp.finora.util.Formatters;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class CardActivity extends AppCompatActivity {
    private List<PaymentMethodBalance> allBalances = new ArrayList<>();
    private List<PaymentMethodBalance> filteredBalances = new ArrayList<>();
    private PaymentMethodBalance selectedCard;
    private String currentFilter = "ALL";

    private TextView tabAll, tabDebit, tabEWallet, tabCash;
    private RelativeLayout cardPreviewBg;
    private TextView tvCardTypeBadge, tvCardNumber, tvCardBalance, tvBankName;
    private TextView tvInfoAccountName, tvInfoCardNumber, tvInfoBalance;
    private RecyclerView rvCards;
    private WalletAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card);

        initViews();
        setupData();
    }

    private void initViews() {
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnAddCard).setOnClickListener(v -> showAddCardDialog());

        tabAll = findViewById(R.id.tabAll);
        tabDebit = findViewById(R.id.tabDebit);
        tabEWallet = findViewById(R.id.tabEWallet);
        tabCash = findViewById(R.id.tabCash);

        tabAll.setOnClickListener(v -> setFilter("ALL"));
        tabDebit.setOnClickListener(v -> setFilter(Constants.PM_BANK));
        tabEWallet.setOnClickListener(v -> setFilter(Constants.PM_EWALLET));
        tabCash.setOnClickListener(v -> setFilter(Constants.PM_CASH));

        cardPreviewBg = findViewById(R.id.cardPreviewBg);
        tvCardTypeBadge = findViewById(R.id.tvCardTypeBadge);
        tvCardNumber = findViewById(R.id.tvCardNumber);
        tvCardBalance = findViewById(R.id.tvCardBalance);
        tvBankName = findViewById(R.id.tvBankName);

        tvInfoAccountName = findViewById(R.id.tvInfoAccountName);
        tvInfoCardNumber = findViewById(R.id.tvInfoCardNumber);
        tvInfoBalance = findViewById(R.id.tvInfoBalance);

        findViewById(R.id.btnEditCard).setOnClickListener(v -> {
            if (selectedCard != null) showEditCardDialog(selectedCard);
        });

        rvCards = findViewById(R.id.rvWalletCards);
        adapter = new WalletAdapter(card -> {
            selectedCard = card;
            renderSelectedCard();
            adapter.notifyDataSetChanged();
        });
        rvCards.setAdapter(adapter);
    }

    private void setupData() {
        int userId = FinoraApp.container(this).session.getUserId();
        FinoraApp.container(this).paymentMethodRepository.balances(userId).observe(this, list -> {
            if (list == null) return;
            allBalances = list;
            applyFilter();
        });
    }

    private void setFilter(String filter) {
        currentFilter = filter;
        updateTabStyles();
        applyFilter();
    }

    private void updateTabStyles() {
        tabAll.setBackgroundResource("ALL".equals(currentFilter) ? R.drawable.bg_chip_selected : android.R.color.transparent);
        tabAll.setTextColor("ALL".equals(currentFilter) ? 0xFFFFFFFF : 0xFF667085);

        tabDebit.setBackgroundResource(Constants.PM_BANK.equals(currentFilter) ? R.drawable.bg_chip_selected : android.R.color.transparent);
        tabDebit.setTextColor(Constants.PM_BANK.equals(currentFilter) ? 0xFFFFFFFF : 0xFF667085);

        tabEWallet.setBackgroundResource(Constants.PM_EWALLET.equals(currentFilter) ? R.drawable.bg_chip_selected : android.R.color.transparent);
        tabEWallet.setTextColor(Constants.PM_EWALLET.equals(currentFilter) ? 0xFFFFFFFF : 0xFF667085);

        tabCash.setBackgroundResource(Constants.PM_CASH.equals(currentFilter) ? R.drawable.bg_chip_selected : android.R.color.transparent);
        tabCash.setTextColor(Constants.PM_CASH.equals(currentFilter) ? 0xFFFFFFFF : 0xFF667085);
    }

    private void applyFilter() {
        filteredBalances.clear();
        for (PaymentMethodBalance b : allBalances) {
            if ("ALL".equals(currentFilter) || currentFilter.equalsIgnoreCase(b.type)) {
                filteredBalances.add(b);
            }
        }
        if (selectedCard == null || !filteredBalances.contains(selectedCard)) {
            if (!filteredBalances.isEmpty()) {
                selectedCard = filteredBalances.get(0);
            }
        }
        adapter.submitList(filteredBalances);
        renderSelectedCard();
    }

    private void renderSelectedCard() {
        if (selectedCard == null) return;

        tvCardTypeBadge.setText(selectedCard.type.toUpperCase(Locale.ROOT));
        String lastDigits = selectedCard.accountNumber != null && !selectedCard.accountNumber.isEmpty()
                ? selectedCard.accountNumber : "821";
        tvCardNumber.setText("••••  ••••  ••••  •" + lastDigits);
        tvCardBalance.setText(Formatters.currency(selectedCard.balance));
        tvBankName.setText(selectedCard.name);

        int bgColor = parseCardColor(selectedCard.color);
        applyCardBackground(cardPreviewBg, bgColor);

        tvInfoAccountName.setText(selectedCard.name + " (" + selectedCard.type + ")");
        tvInfoCardNumber.setText("•••• " + lastDigits);
        tvInfoBalance.setText(Formatters.currency(selectedCard.balance));
    }

    private int parseCardColor(String colorStr) {
        try {
            if (colorStr != null && colorStr.startsWith("#")) {
                return Color.parseColor(colorStr);
            }
        } catch (Exception ignored) { }
        return 0xFF1555E8;
    }

    private void applyCardBackground(View view, int color) {
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{color, darkenColor(color)}
        );
        gd.setCornerRadius(18 * getResources().getDisplayMetrics().density);
        view.setBackground(gd);
    }

    private int darkenColor(int color) {
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        hsv[2] *= 0.75f;
        return Color.HSVToColor(hsv);
    }

    private void showEditCardDialog(PaymentMethodBalance card) {
        BottomSheetDialog dialog = new BottomSheetDialog(this);
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_edit_card, null);
        dialog.setContentView(view);

        RelativeLayout preview = view.findViewById(R.id.dialogCardPreviewBg);
        TextView tvType = view.findViewById(R.id.dialogCardTypeBadge);
        TextView tvNum = view.findViewById(R.id.dialogCardNumber);
        TextView tvBal = view.findViewById(R.id.dialogCardBalance);
        TextView tvBank = view.findViewById(R.id.dialogBankName);

        EditText etName = view.findViewById(R.id.etDialogBankName);
        EditText etBal = view.findViewById(R.id.etDialogBalance);
        EditText etDigits = view.findViewById(R.id.etDialogCardLastDigits);

        final String[] chosenColor = {card.color != null ? card.color : "#1555E8"};

        tvType.setText(card.type.toUpperCase(Locale.ROOT));
        tvNum.setText("••••  ••••  ••••  •" + (card.accountNumber != null ? card.accountNumber : "821"));
        tvBal.setText(Formatters.currency(card.balance));
        tvBank.setText(card.name);
        etName.setText(card.name);
        etBal.setText(String.format(Locale.US, "%.0f", card.balance));
        etDigits.setText(card.accountNumber != null ? card.accountNumber : "821");

        applyCardBackground(preview, parseCardColor(chosenColor[0]));

        // Color clicks
        view.findViewById(R.id.colorBlue).setOnClickListener(v -> {
            chosenColor[0] = "#1555E8";
            applyCardBackground(preview, parseCardColor(chosenColor[0]));
        });
        view.findViewById(R.id.colorOrange).setOnClickListener(v -> {
            chosenColor[0] = "#F97316";
            applyCardBackground(preview, parseCardColor(chosenColor[0]));
        });
        view.findViewById(R.id.colorGreen).setOnClickListener(v -> {
            chosenColor[0] = "#00A879";
            applyCardBackground(preview, parseCardColor(chosenColor[0]));
        });
        view.findViewById(R.id.colorPurple).setOnClickListener(v -> {
            chosenColor[0] = "#8B5CF6";
            applyCardBackground(preview, parseCardColor(chosenColor[0]));
        });
        view.findViewById(R.id.colorPink).setOnClickListener(v -> {
            chosenColor[0] = "#EC4899";
            applyCardBackground(preview, parseCardColor(chosenColor[0]));
        });
        view.findViewById(R.id.colorDark).setOnClickListener(v -> {
            chosenColor[0] = "#182033";
            applyCardBackground(preview, parseCardColor(chosenColor[0]));
        });

        view.findViewById(R.id.btnCloseDialog).setOnClickListener(v -> dialog.dismiss());

        view.findViewById(R.id.btnSaveCardChanges).setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String balStr = etBal.getText().toString().trim();
            String digits = etDigits.getText().toString().trim();
            if (name.isEmpty() || balStr.isEmpty()) {
                Toast.makeText(this, "Nama dan saldo wajib diisi", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                double newBal = Double.parseDouble(balStr);
                FinoraApp.container(this).paymentMethodRepository.update(
                        card.id, name, chosenColor[0], newBal, digits, () -> {
                            Toast.makeText(this, "Perubahan kartu berhasil disimpan", Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                        });
            } catch (Exception e) {
                Toast.makeText(this, "Format saldo tidak valid", Toast.LENGTH_SHORT).show();
            }
        });

        view.findViewById(R.id.btnDeleteCard).setOnClickListener(v -> {
            new MaterialAlertDialogBuilder(this)
                    .setTitle("Hapus Kartu")
                    .setMessage("Yakin ingin menghapus " + card.name + "?")
                    .setPositiveButton("Hapus", (d, w) -> {
                        FinoraApp.container(this).paymentMethodRepository.delete(card.id, () -> {
                            Toast.makeText(this, "Kartu berhasil dihapus", Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                        });
                    })
                    .setNegativeButton("Batal", null)
                    .show();
        });

        dialog.show();
    }

    private void showAddCardDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_card, null);
        EditText etName = dialogView.findViewById(R.id.etCardName);
        EditText etBalance = dialogView.findViewById(R.id.etCardBalance);
        android.widget.Spinner spType = dialogView.findViewById(R.id.spCardType);

        String[] types = {"Bank", "E-Wallet", "Tunai", "Kartu"};
        String[] typeKeys = {Constants.PM_BANK, Constants.PM_EWALLET, Constants.PM_CASH, Constants.PM_CARD};

        android.widget.ArrayAdapter<String> a = new android.widget.ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, types);
        spType.setAdapter(a);

        new MaterialAlertDialogBuilder(this)
                .setTitle("Tambah Kartu / Dompet Baru")
                .setView(dialogView)
                .setPositiveButton("Simpan", (dialog, which) -> {
                    String name = etName.getText().toString().trim();
                    String balStr = etBalance.getText().toString().trim();
                    if (!name.isEmpty() && !balStr.isEmpty()) {
                        try {
                            double bal = Double.parseDouble(balStr);
                            int pos = spType.getSelectedItemPosition();
                            String type = typeKeys[pos];
                            int userId = FinoraApp.container(this).session.getUserId();
                            PaymentMethodEntity entity = new PaymentMethodEntity(userId, name, type, bal, "821", "#1555E8");
                            FinoraApp.container(this).paymentMethodRepository.add(entity);
                            Toast.makeText(this, "Kartu berhasil ditambahkan", Toast.LENGTH_SHORT).show();
                        } catch (Exception ignored) { }
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    interface OnCardClick { void onClick(PaymentMethodBalance b); }

    class WalletAdapter extends RecyclerView.Adapter<WalletAdapter.Holder> {
        private final List<PaymentMethodBalance> items = new ArrayList<>();
        private final OnCardClick listener;

        WalletAdapter(OnCardClick listener) { this.listener = listener; }

        void submitList(List<PaymentMethodBalance> list) {
            items.clear();
            if (list != null) items.addAll(list);
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_wallet_card, parent, false);
            return new Holder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull Holder holder, int position) {
            PaymentMethodBalance item = items.get(position);
            holder.tvName.setText(item.name);
            holder.tvTypeNumber.setText(item.type + " • •••• " + (item.accountNumber != null ? item.accountNumber : "821"));
            holder.tvBalance.setText(Formatters.currency(item.balance));

            int c = parseCardColor(item.color);
            holder.viewPill.setBackgroundColor(c);

            boolean isSelected = selectedCard != null && selectedCard.id == item.id;
            holder.tvSelected.setVisibility(isSelected ? View.VISIBLE : View.GONE);

            holder.itemView.setOnClickListener(v -> {
                if (listener != null) listener.onClick(item);
            });
        }

        @Override
        public int getItemCount() { return items.size(); }

        class Holder extends RecyclerView.ViewHolder {
            final View viewPill;
            final TextView tvName, tvTypeNumber, tvBalance, tvSelected;
            Holder(View v) {
                super(v);
                viewPill = v.findViewById(R.id.viewColorPill);
                tvName = v.findViewById(R.id.tvWalletName);
                tvTypeNumber = v.findViewById(R.id.tvWalletTypeNumber);
                tvBalance = v.findViewById(R.id.tvWalletBalance);
                tvSelected = v.findViewById(R.id.tvWalletSelectedBadge);
            }
        }
    }
}
