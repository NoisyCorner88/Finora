package com.ncp.finora.data.local.model;

import androidx.room.ColumnInfo;

/** Sumber dana beserta saldo berjalan (saldo awal + pemasukan - pengeluaran). */
public class PaymentMethodBalance {
    public int id;
    public String name;
    public String type;
    public double balance;
    @ColumnInfo(name = "account_number")
    public String accountNumber = "821";
    public String color = "#1555E8";
}
