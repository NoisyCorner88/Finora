package com.ncp.finora.ui.activity;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.ncp.finora.data.repository.TransactionRepository;
import com.ncp.finora.ui.model.TransactionUi;
import com.ncp.finora.util.Constants;

import java.util.List;

public class ActivityViewModel extends ViewModel {
    private final MutableLiveData<String> filter = new MutableLiveData<>(Constants.ALL);
    private final LiveData<List<TransactionUi>> transactions;

    public ActivityViewModel(int userId, TransactionRepository repo) {
        transactions = Transformations.switchMap(filter, f ->
                Transformations.map(repo.byType(userId, f), TransactionUi::fromList));
    }

    public LiveData<String> getFilter() { return filter; }
    public LiveData<List<TransactionUi>> getTransactions() { return transactions; }

    public void setFilter(String type) {
        if (!type.equals(filter.getValue())) filter.setValue(type);
    }
}
