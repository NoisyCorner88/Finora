package com.ncp.finora.util;

import com.google.mlkit.vision.text.Text;
import com.ncp.finora.data.local.entity.ReceiptItemEntity;
import com.ncp.finora.data.local.model.ParsedReceipt;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReceiptOcrParser {

    private static final Pattern PRICE_PATTERN =
            Pattern.compile("(?:rp\\.?[\\s]*)?([0-9]{1,3}(?:[.,][0-9]{3})*(?:[.,][0-9]{2})?|[0-9]+)", Pattern.CASE_INSENSITIVE);

    private static final Pattern DATE_PATTERN =
            Pattern.compile("([0-3]?[0-9][/-][0-1]?[0-9][/-][0-9]{2,4})", Pattern.CASE_INSENSITIVE);

    private static final Pattern TIME_PATTERN =
            Pattern.compile("([0-2]?[0-9][:.][0-5][0-9](?:[:.][0-5][0-9])?)");

    public static ParsedReceipt parse(Text mlKitText, String imagePath) {
        ParsedReceipt receipt = new ParsedReceipt();
        receipt.imagePath = imagePath != null ? imagePath : "";
        if (mlKitText == null) return receipt;

        receipt.rawText = mlKitText.getText();
        List<String> lines = new ArrayList<>();
        for (Text.TextBlock block : mlKitText.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String text = line.getText().trim();
                if (!text.isEmpty()) {
                    lines.add(text);
                }
            }
        }

        if (lines.isEmpty()) {
            setDefaultDate(receipt);
            return receipt;
        }

        // 1. Merchant Name: look at the first few lines
        receipt.merchantName = extractMerchantName(lines);

        // 2. Date and Time
        extractDateTime(lines, receipt);

        // 3. Extract Totals, Subtotal, Tax, Discount
        extractTotalsAndAmounts(lines, receipt);

        // 4. Extract Line Items
        extractItems(lines, receipt);

        // 5. Fallback calculations
        if (receipt.total == 0 && receipt.subtotal > 0) {
            receipt.total = receipt.subtotal + receipt.tax - receipt.discount;
        } else if (receipt.total == 0 && !receipt.items.isEmpty()) {
            double sum = 0;
            for (ReceiptItemEntity item : receipt.items) {
                sum += item.unitPrice * item.quantity;
            }
            receipt.total = sum;
            if (receipt.subtotal == 0) receipt.subtotal = sum;
        } else if (receipt.subtotal == 0 && receipt.total > 0) {
            receipt.subtotal = receipt.total - receipt.tax + receipt.discount;
        }

        // 6. Category prediction
        receipt.categoryName = predictCategory(receipt.merchantName, receipt.rawText);

        return receipt;
    }

    private static String extractMerchantName(List<String> lines) {
        String[] knownMerchants = {
                "Indomaret", "Alfamart", "Kopi Kenangan", "Starbucks", "Janji Jiwa",
                "Superindo", "Hypermart", "Transmart", "Lawson", "Circle K",
                "Mc Donald's", "McDonalds", "KFC", "Burger King", "Pizza Hut",
                "J.CO", "Chatime", "FamilyMart", "Gojek", "Grab", "Pertamina"
        };

        for (int i = 0; i < Math.min(lines.size(), 8); i++) {
            String line = lines.get(i);
            for (String merchant : knownMerchants) {
                if (line.toLowerCase(Locale.ROOT).contains(merchant.toLowerCase(Locale.ROOT))) {
                    return line;
                }
            }
        }

        // Fallback: choose the first line that is not a date/number/address/phone
        for (int i = 0; i < Math.min(lines.size(), 5); i++) {
            String line = lines.get(i);
            String lower = line.toLowerCase(Locale.ROOT);
            if (lower.startsWith("jl.") || lower.startsWith("jalan") || lower.contains("telp")
                    || lower.contains("npwp") || lower.contains("struk") || lower.contains("nota")
                    || DATE_PATTERN.matcher(line).find() || line.length() < 3) {
                continue;
            }
            return line;
        }

        return !lines.isEmpty() ? lines.get(0) : "Toko / Merchant";
    }

    private static void extractDateTime(List<String> lines, ParsedReceipt receipt) {
        String foundDate = null;
        String foundTime = null;

        for (String line : lines) {
            if (foundDate == null) {
                Matcher mDate = DATE_PATTERN.matcher(line);
                if (mDate.find()) {
                    foundDate = mDate.group(1);
                }
            }
            if (foundTime == null) {
                Matcher mTime = TIME_PATTERN.matcher(line);
                if (mTime.find()) {
                    foundTime = mTime.group(1);
                }
            }
            if (foundDate != null && foundTime != null) break;
        }

        SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        SimpleDateFormat displayFormat = new SimpleDateFormat("d MMMM yyyy", new Locale("id", "ID"));
        Date now = new Date();

        if (foundDate != null) {
            try {
                String clean = foundDate.replace('-', '/');
                String[] parts = clean.split("/");
                int day = Integer.parseInt(parts[0]);
                int month = Integer.parseInt(parts[1]);
                int year = Integer.parseInt(parts[2]);
                if (year < 100) year += 2000;
                receipt.transactionDate = String.format(Locale.US, "%04d-%02d-%02d", year, month, day);
                receipt.formattedDateTime = String.format(Locale.US, "%d %s %d", day, getMonthName(month), year);
            } catch (Exception e) {
                receipt.transactionDate = isoFormat.format(now);
                receipt.formattedDateTime = displayFormat.format(now);
            }
        } else {
            receipt.transactionDate = isoFormat.format(now);
            receipt.formattedDateTime = displayFormat.format(now);
        }

        if (foundTime != null) {
            receipt.formattedDateTime += ", " + foundTime + " WIB";
        } else {
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH.mm", Locale.US);
            receipt.formattedDateTime += ", " + timeFormat.format(now) + " WIB";
        }
    }

    private static void extractTotalsAndAmounts(List<String> lines, ParsedReceipt receipt) {
        for (String line : lines) {
            String upper = line.toUpperCase(Locale.ROOT);
            double val = extractLastPrice(line);
            if (val <= 0) continue;

            if (upper.contains("SUBTOTAL") || upper.contains("SUB TOTAL")) {
                receipt.subtotal = val;
            } else if (upper.contains("TOTAL") || upper.contains("GRAND TOTAL") || upper.contains("JUMLAH")) {
                if (!upper.contains("ITEM") && !upper.contains("QTY")) {
                    receipt.total = val;
                }
            } else if (upper.contains("DISKON") || upper.contains("DISCOUNT") || upper.contains("POTONGAN") || upper.contains("PROMO")) {
                receipt.discount = val;
            } else if (upper.contains("PAJAK") || upper.contains("PB1") || upper.contains("PPN") || upper.contains("TAX")) {
                receipt.tax = val;
            }
        }
    }

    private static void extractItems(List<String> lines, ParsedReceipt receipt) {
        List<ReceiptItemEntity> items = new ArrayList<>();
        boolean startItems = false;

        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            String upper = line.toUpperCase(Locale.ROOT);

            if (upper.contains("TOTAL") || upper.contains("BAYAR") || upper.contains("TUNAI")
                    || upper.contains("KEMBALI") || upper.contains("KARTU") || upper.contains("DEBIT")) {
                break;
            }

            double price = extractLastPrice(line);
            if (price > 100 && !upper.contains("TELP") && !upper.contains("NO.") && !upper.contains("NPWP")) {
                String name = line.replaceAll("(?:rp\\.?[\\s]*)?[0-9]{1,3}(?:[.,][0-9]{3})*(?:[.,][0-9]{2})?|[0-9]+", "").trim();
                name = name.replaceAll("^[0-9]+[\\s]*[xX*][\\s]*", "").trim();
                if (name.length() >= 2 && !isIgnoredWord(name)) {
                    ReceiptItemEntity item = new ReceiptItemEntity();
                    item.itemName = name;
                    item.quantity = 1;
                    item.unitPrice = price;
                    items.add(item);
                }
            }
        }

        if (items.isEmpty() && receipt.total > 0) {
            ReceiptItemEntity item = new ReceiptItemEntity();
            item.itemName = receipt.merchantName.isEmpty() ? "Pembelian Struk" : receipt.merchantName;
            item.quantity = 1;
            item.unitPrice = receipt.total;
            items.add(item);
        }

        receipt.items = items;
    }

    private static boolean isIgnoredWord(String text) {
        String u = text.toUpperCase(Locale.ROOT);
        return u.contains("STRUK") || u.contains("TANGGAL") || u.contains("KASIR")
                || u.contains("SELAMAT") || u.contains("DATANG") || u.contains("TERIMA KASIH")
                || u.contains("WIB") || u.contains("TUNAI") || u.contains("DEBIT");
    }

    private static double extractLastPrice(String line) {
        Matcher matcher = PRICE_PATTERN.matcher(line);
        double lastPrice = -1;
        while (matcher.find()) {
            String numStr = matcher.group(1);
            if (numStr == null) continue;
            numStr = numStr.replace(".", "").replace(",", ".");
            try {
                double val = Double.parseDouble(numStr);
                lastPrice = val;
            } catch (Exception ignored) { }
        }
        return lastPrice;
    }

    private static String predictCategory(String merchant, String fullText) {
        String combined = (merchant + " " + fullText).toLowerCase(Locale.ROOT);
        if (combined.contains("kopi") || combined.contains("cafe") || combined.contains("resto")
                || combined.contains("makan") || combined.contains("ayam") || combined.contains("burger")
                || combined.contains("pizza") || combined.contains("susu") || combined.contains("teh")
                || combined.contains("starbucks") || combined.contains("mcdonald")) {
            return "Makanan";
        }
        if (combined.contains("spbu") || combined.contains("pertamina") || combined.contains("shell")
                || combined.contains("bensin") || combined.contains("grab") || combined.contains("gojek")
                || combined.contains("parkir") || combined.contains("tol")) {
            return "Transportasi";
        }
        if (combined.contains("pln") || combined.contains("listrik") || combined.contains("air")
                || combined.contains("pdam") || combined.contains("wifi") || combined.contains("indihome")
                || combined.contains("pulsa") || combined.contains("kuota")) {
            return "Tagihan";
        }
        return "Belanja";
    }

    private static void setDefaultDate(ParsedReceipt receipt) {
        SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        SimpleDateFormat displayFormat = new SimpleDateFormat("d MMMM yyyy, HH.mm 'WIB'", new Locale("id", "ID"));
        Date now = new Date();
        receipt.transactionDate = isoFormat.format(now);
        receipt.formattedDateTime = displayFormat.format(now);
    }

    private static String getMonthName(int m) {
        String[] months = {"Januari", "Februari", "Maret", "April", "Mei", "Juni",
                "Juli", "Agustus", "September", "Oktober", "November", "Desember"};
        if (m >= 1 && m <= 12) return months[m - 1];
        return "";
    }
}
